#
#	configuration variables for the example

## Main application file
MAIN = testrolx
DEPH = $(EXSNAPADV)/rolx.h
DEPCPP = $(EXSNAPADV)/rolx.cpp
CXXFLAGS += $(CXXOPENMP)

