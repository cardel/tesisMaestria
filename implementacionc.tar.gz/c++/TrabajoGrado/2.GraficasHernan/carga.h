#ifndef CARGA_H
#define CARGA_H
#include "Snap.h"
#include "gnuplot.h"
#include "bd.h"

#endif
