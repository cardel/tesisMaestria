python pruebasFractalidad.py --type SmallWorld --output SmallWorld50d100 --message SmallWorld50d100 --node 100 --desired 1000 
python pruebasFractalidad.py --type ScaleFreePrefAttach --output ScaleFreePrefAttach50d100 --message ScaleFreePrefAttach50d100 --node 100 --desired 1000 
python pruebasFractalidad.py --type Random --output Random50d100 --message Random50d100 --node 100 --desired 1000 
