#/bin/sh
python pruebasRobustez.py  --file ../datos/karate.net --type Pajek --output karate
