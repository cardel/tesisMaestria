#!/bin/sh
cd ..
python pruebasFractalidad.py --type ScaleFreePrefAttach --output ScaleFreePrefAttach2000-20000 --message ScaleFreePrefAttach2000-20000 --node 2000 --desired 20000 

python pruebasFractalidad.py --file ../datos/flower.txt --type Edge --output flower --message "flower"  
