 python pruebasRobustez.py  --file ../datos/karate.net --type Pajek --output karate --measure APL --attack random
 
 python pruebasRobustez.py  --file ../datos/karate.net --type Pajek --output karate --measure GC --attack random

