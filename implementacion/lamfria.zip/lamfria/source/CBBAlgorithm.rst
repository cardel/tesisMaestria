CBBAlgorithm package
====================

Submodules
----------

CBBAlgorithm.CBBAlgorithm module
--------------------------------

.. automodule:: CBBAlgorithm.CBBAlgorithm
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: CBBAlgorithm
    :members:
    :undoc-members:
    :show-inheritance:
